# Subtitle Samples for jsubs-addon

Includes example subtitles for Inception (tt1375666) in English, Japanese, and Malay.